from __future__ import annotations

import os
from datetime import date, datetime, timedelta
from pathlib import Path

from flask import Flask, flash, redirect, render_template, request, url_for
from flask_login import LoginManager, UserMixin, current_user, login_required, login_user, logout_user
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import check_password_hash, generate_password_hash

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "fleet.db"

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "fleet-management-secret-key")
app.config["SQLALCHEMY_DATABASE_URI"] = f"sqlite:///{DB_PATH}"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False


db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = "login"
login_manager.login_message_category = "warning"


class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    full_name = db.Column(db.String(120), nullable=False)
    role = db.Column(db.String(50), default="Administrator")

    def set_password(self, password: str) -> None:
        self.password_hash = generate_password_hash(password)

    def check_password(self, password: str) -> bool:
        return check_password_hash(self.password_hash, password)


class Vehicle(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    plate_number = db.Column(db.String(20), unique=True, nullable=False)
    make = db.Column(db.String(80), nullable=False)
    model = db.Column(db.String(80), nullable=False)
    year = db.Column(db.Integer, nullable=False)
    status = db.Column(db.String(30), default="Available")
    odometer = db.Column(db.Integer, default=0)
    fuel_type = db.Column(db.String(30), default="Diesel")
    insurance_expiry = db.Column(db.Date, nullable=True)
    registration_expiry = db.Column(db.Date, nullable=True)
    assigned_driver = db.Column(db.String(120), nullable=True)

    trips = db.relationship("Trip", backref="vehicle", lazy=True, cascade="all, delete-orphan")
    fuel_logs = db.relationship("FuelLog", backref="vehicle", lazy=True, cascade="all, delete-orphan")
    maintenance_records = db.relationship("MaintenanceRecord", backref="vehicle", lazy=True, cascade="all, delete-orphan")


class Driver(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    phone = db.Column(db.String(30), nullable=False)
    license_number = db.Column(db.String(50), unique=True, nullable=False)
    license_expiry = db.Column(db.Date, nullable=False)
    status = db.Column(db.String(30), default="Available")
    hire_date = db.Column(db.Date, nullable=False)

    trips = db.relationship("Trip", backref="driver", lazy=True, cascade="all, delete-orphan")


class Trip(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    vehicle_id = db.Column(db.Integer, db.ForeignKey("vehicle.id"), nullable=False)
    driver_id = db.Column(db.Integer, db.ForeignKey("driver.id"), nullable=False)
    origin = db.Column(db.String(120), nullable=False)
    destination = db.Column(db.String(120), nullable=False)
    start_date = db.Column(db.Date, nullable=False)
    end_date = db.Column(db.Date, nullable=True)
    distance_km = db.Column(db.Float, default=0)
    cargo = db.Column(db.String(120), nullable=True)
    status = db.Column(db.String(30), default="Scheduled")
    notes = db.Column(db.Text, nullable=True)


class MaintenanceRecord(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    vehicle_id = db.Column(db.Integer, db.ForeignKey("vehicle.id"), nullable=False)
    service_type = db.Column(db.String(120), nullable=False)
    service_date = db.Column(db.Date, nullable=False)
    next_due_date = db.Column(db.Date, nullable=True)
    cost = db.Column(db.Float, default=0)
    vendor = db.Column(db.String(120), nullable=True)
    status = db.Column(db.String(30), default="Completed")
    notes = db.Column(db.Text, nullable=True)


class FuelLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    vehicle_id = db.Column(db.Integer, db.ForeignKey("vehicle.id"), nullable=False)
    refuel_date = db.Column(db.Date, nullable=False)
    liters = db.Column(db.Float, nullable=False)
    price_per_liter = db.Column(db.Float, nullable=False)
    odometer = db.Column(db.Integer, nullable=False)
    station = db.Column(db.String(120), nullable=True)

    @property
    def total_cost(self) -> float:
        return round(self.liters * self.price_per_liter, 2)


@login_manager.user_loader
def load_user(user_id: str):
    return User.query.get(int(user_id))


@app.context_processor
def inject_globals():
    return {"today": date.today(), "current_year": date.today().year}


def parse_date(value: str | None):
    if not value:
        return None
    return datetime.strptime(value, "%Y-%m-%d").date()


def safe_int(value, default=0):
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def safe_float(value, default=0.0):
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def seed_database() -> None:
    if User.query.first():
        return

    admin = User(username="admin", full_name="System Administrator", role="Administrator")
    admin.set_password("admin123")
    db.session.add(admin)

    vehicles = [
        Vehicle(
            plate_number="FM-1024",
            make="Toyota",
            model="Hilux",
            year=2023,
            status="Available",
            odometer=45210,
            fuel_type="Diesel",
            insurance_expiry=date.today() + timedelta(days=22),
            registration_expiry=date.today() + timedelta(days=140),
            assigned_driver="Michael Grant",
        ),
        Vehicle(
            plate_number="FM-2048",
            make="Ford",
            model="Transit",
            year=2022,
            status="On Trip",
            odometer=80124,
            fuel_type="Diesel",
            insurance_expiry=date.today() + timedelta(days=67),
            registration_expiry=date.today() + timedelta(days=92),
            assigned_driver="Sarah Kim",
        ),
        Vehicle(
            plate_number="FM-4096",
            make="Isuzu",
            model="N-Series",
            year=2021,
            status="Maintenance",
            odometer=120405,
            fuel_type="Diesel",
            insurance_expiry=date.today() + timedelta(days=45),
            registration_expiry=date.today() + timedelta(days=15),
            assigned_driver="",
        ),
    ]
    db.session.add_all(vehicles)

    drivers = [
        Driver(
            name="Michael Grant",
            phone="+1-555-0101",
            license_number="DRV-1001",
            license_expiry=date.today() + timedelta(days=120),
            status="Available",
            hire_date=date.today() - timedelta(days=800),
        ),
        Driver(
            name="Sarah Kim",
            phone="+1-555-0102",
            license_number="DRV-1002",
            license_expiry=date.today() + timedelta(days=18),
            status="On Trip",
            hire_date=date.today() - timedelta(days=560),
        ),
        Driver(
            name="Ahmed Noor",
            phone="+1-555-0103",
            license_number="DRV-1003",
            license_expiry=date.today() + timedelta(days=210),
            status="Leave",
            hire_date=date.today() - timedelta(days=350),
        ),
    ]
    db.session.add_all(drivers)
    db.session.flush()

    trips = [
        Trip(
            vehicle_id=1,
            driver_id=1,
            origin="Chicago",
            destination="Milwaukee",
            start_date=date.today() - timedelta(days=3),
            end_date=date.today() - timedelta(days=2),
            distance_km=148,
            cargo="Food delivery",
            status="Completed",
            notes="On-time delivery completed.",
        ),
        Trip(
            vehicle_id=2,
            driver_id=2,
            origin="Dallas",
            destination="Houston",
            start_date=date.today() - timedelta(days=1),
            end_date=None,
            distance_km=393,
            cargo="Medical supplies",
            status="In Progress",
            notes="Live tracking active.",
        ),
        Trip(
            vehicle_id=1,
            driver_id=1,
            origin="Chicago",
            destination="Madison",
            start_date=date.today() + timedelta(days=1),
            end_date=date.today() + timedelta(days=2),
            distance_km=235,
            cargo="Electronics",
            status="Scheduled",
            notes="Dispatch approved.",
        ),
    ]
    db.session.add_all(trips)

    maintenance = [
        MaintenanceRecord(
            vehicle_id=3,
            service_type="Brake inspection",
            service_date=date.today() - timedelta(days=2),
            next_due_date=date.today() + timedelta(days=28),
            cost=640,
            vendor="FleetFix Garage",
            status="Open",
            notes="Pads replacement pending",
        ),
        MaintenanceRecord(
            vehicle_id=2,
            service_type="Oil change",
            service_date=date.today() - timedelta(days=40),
            next_due_date=date.today() + timedelta(days=20),
            cost=130,
            vendor="QuickLube",
            status="Completed",
            notes="Routine service",
        ),
    ]
    db.session.add_all(maintenance)

    fuel_logs = [
        FuelLog(
            vehicle_id=1,
            refuel_date=date.today() - timedelta(days=4),
            liters=62,
            price_per_liter=1.45,
            odometer=45010,
            station="Shell",
        ),
        FuelLog(
            vehicle_id=2,
            refuel_date=date.today() - timedelta(days=1),
            liters=80,
            price_per_liter=1.52,
            odometer=79900,
            station="Exxon",
        ),
        FuelLog(
            vehicle_id=3,
            refuel_date=date.today() - timedelta(days=9),
            liters=74,
            price_per_liter=1.49,
            odometer=120100,
            station="BP",
        ),
    ]
    db.session.add_all(fuel_logs)
    db.session.commit()


with app.app_context():
    db.create_all()
    seed_database()


@app.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard"))

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        user = User.query.filter_by(username=username).first()
        if user and user.check_password(password):
            login_user(user)
            flash("Welcome back.", "success")
            return redirect(url_for("dashboard"))
        flash("Invalid credentials.", "danger")
    return render_template("login.html")


@app.route("/logout")
@login_required
def logout():
    logout_user()
    flash("You have been logged out.", "info")
    return redirect(url_for("login"))


@app.route("/")
@login_required
def dashboard():
    today = date.today()
    month_start = today.replace(day=1)

    vehicles = Vehicle.query.all()
    drivers = Driver.query.all()
    active_trips = Trip.query.filter(Trip.status.in_(["In Progress", "Scheduled"])).count()
    due_maintenance = MaintenanceRecord.query.filter(
        (MaintenanceRecord.status == "Open")
        | ((MaintenanceRecord.next_due_date.isnot(None)) & (MaintenanceRecord.next_due_date <= today + timedelta(days=30)))
    ).count()

    fuel_total = sum(log.total_cost for log in FuelLog.query.filter(FuelLog.refuel_date >= month_start).all())
    maintenance_total = sum(item.cost for item in MaintenanceRecord.query.filter(MaintenanceRecord.service_date >= month_start).all())

    alerts = []
    for vehicle in vehicles:
        if vehicle.insurance_expiry and vehicle.insurance_expiry <= today + timedelta(days=30):
            alerts.append({"type": "Insurance", "message": f"{vehicle.plate_number} insurance expires on {vehicle.insurance_expiry}"})
        if vehicle.registration_expiry and vehicle.registration_expiry <= today + timedelta(days=30):
            alerts.append({"type": "Registration", "message": f"{vehicle.plate_number} registration expires on {vehicle.registration_expiry}"})

    for driver in drivers:
        if driver.license_expiry <= today + timedelta(days=30):
            alerts.append({"type": "License", "message": f"{driver.name} license expires on {driver.license_expiry}"})

    for item in MaintenanceRecord.query.filter_by(status="Open").all():
        alerts.append({"type": "Maintenance", "message": f"{item.vehicle.plate_number} has open service: {item.service_type}"})

    recent_trips = Trip.query.order_by(Trip.start_date.desc()).limit(5).all()

    status_counts = {
        "Available": Vehicle.query.filter_by(status="Available").count(),
        "On Trip": Vehicle.query.filter_by(status="On Trip").count(),
        "Maintenance": Vehicle.query.filter_by(status="Maintenance").count(),
    }

    return render_template(
        "dashboard.html",
        metrics={
            "total_vehicles": len(vehicles),
            "available_vehicles": status_counts["Available"],
            "drivers": len(drivers),
            "active_trips": active_trips,
            "due_maintenance": due_maintenance,
            "fuel_total": round(fuel_total, 2),
            "maintenance_total": round(maintenance_total, 2),
        },
        alerts=alerts[:8],
        recent_trips=recent_trips,
        status_counts=status_counts,
    )


@app.route("/vehicles")
@login_required
def vehicles_list():
    vehicles = Vehicle.query.order_by(Vehicle.id.desc()).all()
    return render_template("vehicles.html", vehicles=vehicles)


@app.route("/vehicles/create", methods=["GET", "POST"])
@app.route("/vehicles/<int:vehicle_id>/edit", methods=["GET", "POST"])
@login_required
def vehicle_form(vehicle_id=None):
    vehicle = Vehicle.query.get_or_404(vehicle_id) if vehicle_id else Vehicle()
    if request.method == "POST":
        vehicle.plate_number = request.form.get("plate_number", "").strip().upper()
        vehicle.make = request.form.get("make", "").strip()
        vehicle.model = request.form.get("model", "").strip()
        vehicle.year = safe_int(request.form.get("year"), date.today().year)
        vehicle.status = request.form.get("status", "Available")
        vehicle.odometer = safe_int(request.form.get("odometer"), 0)
        vehicle.fuel_type = request.form.get("fuel_type", "Diesel")
        vehicle.assigned_driver = request.form.get("assigned_driver", "").strip()
        vehicle.insurance_expiry = parse_date(request.form.get("insurance_expiry"))
        vehicle.registration_expiry = parse_date(request.form.get("registration_expiry"))

        if not vehicle_id:
            db.session.add(vehicle)
        db.session.commit()
        flash("Vehicle saved successfully.", "success")
        return redirect(url_for("vehicles_list"))
    return render_template("vehicle_form.html", vehicle=vehicle)


@app.post("/vehicles/<int:vehicle_id>/delete")
@login_required
def vehicle_delete(vehicle_id):
    vehicle = Vehicle.query.get_or_404(vehicle_id)
    db.session.delete(vehicle)
    db.session.commit()
    flash("Vehicle deleted.", "info")
    return redirect(url_for("vehicles_list"))


@app.route("/drivers")
@login_required
def drivers_list():
    drivers = Driver.query.order_by(Driver.id.desc()).all()
    return render_template("drivers.html", drivers=drivers)


@app.route("/drivers/create", methods=["GET", "POST"])
@app.route("/drivers/<int:driver_id>/edit", methods=["GET", "POST"])
@login_required
def driver_form(driver_id=None):
    driver = Driver.query.get_or_404(driver_id) if driver_id else Driver(hire_date=date.today(), license_expiry=date.today())
    if request.method == "POST":
        driver.name = request.form.get("name", "").strip()
        driver.phone = request.form.get("phone", "").strip()
        driver.license_number = request.form.get("license_number", "").strip().upper()
        driver.license_expiry = parse_date(request.form.get("license_expiry")) or date.today()
        driver.status = request.form.get("status", "Available")
        driver.hire_date = parse_date(request.form.get("hire_date")) or date.today()
        if not driver_id:
            db.session.add(driver)
        db.session.commit()
        flash("Driver saved successfully.", "success")
        return redirect(url_for("drivers_list"))
    return render_template("driver_form.html", driver=driver)


@app.post("/drivers/<int:driver_id>/delete")
@login_required
def driver_delete(driver_id):
    driver = Driver.query.get_or_404(driver_id)
    db.session.delete(driver)
    db.session.commit()
    flash("Driver deleted.", "info")
    return redirect(url_for("drivers_list"))


@app.route("/trips")
@login_required
def trips_list():
    trips = Trip.query.order_by(Trip.start_date.desc()).all()
    return render_template("trips.html", trips=trips)


@app.route("/trips/create", methods=["GET", "POST"])
@app.route("/trips/<int:trip_id>/edit", methods=["GET", "POST"])
@login_required
def trip_form(trip_id=None):
    trip = Trip.query.get_or_404(trip_id) if trip_id else Trip(start_date=date.today())
    vehicles = Vehicle.query.order_by(Vehicle.plate_number).all()
    drivers = Driver.query.order_by(Driver.name).all()

    if request.method == "POST":
        trip.vehicle_id = safe_int(request.form.get("vehicle_id"))
        trip.driver_id = safe_int(request.form.get("driver_id"))
        trip.origin = request.form.get("origin", "").strip()
        trip.destination = request.form.get("destination", "").strip()
        trip.start_date = parse_date(request.form.get("start_date")) or date.today()
        trip.end_date = parse_date(request.form.get("end_date"))
        trip.distance_km = safe_float(request.form.get("distance_km"), 0)
        trip.cargo = request.form.get("cargo", "").strip()
        trip.status = request.form.get("status", "Scheduled")
        trip.notes = request.form.get("notes", "").strip()
        if not trip_id:
            db.session.add(trip)
        db.session.commit()

        vehicle = Vehicle.query.get(trip.vehicle_id)
        driver = Driver.query.get(trip.driver_id)
        if vehicle:
            vehicle.status = "On Trip" if trip.status in ["Scheduled", "In Progress"] else "Available"
            vehicle.assigned_driver = driver.name if driver else vehicle.assigned_driver
        if driver:
            driver.status = "On Trip" if trip.status in ["Scheduled", "In Progress"] else "Available"
        db.session.commit()

        flash("Trip saved successfully.", "success")
        return redirect(url_for("trips_list"))
    return render_template("trip_form.html", trip=trip, vehicles=vehicles, drivers=drivers)


@app.post("/trips/<int:trip_id>/delete")
@login_required
def trip_delete(trip_id):
    trip = Trip.query.get_or_404(trip_id)
    db.session.delete(trip)
    db.session.commit()
    flash("Trip deleted.", "info")
    return redirect(url_for("trips_list"))


@app.route("/maintenance")
@login_required
def maintenance_list():
    records = MaintenanceRecord.query.order_by(MaintenanceRecord.service_date.desc()).all()
    return render_template("maintenance.html", records=records)


@app.route("/maintenance/create", methods=["GET", "POST"])
@app.route("/maintenance/<int:record_id>/edit", methods=["GET", "POST"])
@login_required
def maintenance_form(record_id=None):
    record = MaintenanceRecord.query.get_or_404(record_id) if record_id else MaintenanceRecord(service_date=date.today())
    vehicles = Vehicle.query.order_by(Vehicle.plate_number).all()
    if request.method == "POST":
        record.vehicle_id = safe_int(request.form.get("vehicle_id"))
        record.service_type = request.form.get("service_type", "").strip()
        record.service_date = parse_date(request.form.get("service_date")) or date.today()
        record.next_due_date = parse_date(request.form.get("next_due_date"))
        record.cost = safe_float(request.form.get("cost"), 0)
        record.vendor = request.form.get("vendor", "").strip()
        record.status = request.form.get("status", "Completed")
        record.notes = request.form.get("notes", "").strip()
        if not record_id:
            db.session.add(record)
        db.session.commit()

        vehicle = Vehicle.query.get(record.vehicle_id)
        if vehicle:
            vehicle.status = "Maintenance" if record.status == "Open" else vehicle.status
            db.session.commit()

        flash("Maintenance record saved successfully.", "success")
        return redirect(url_for("maintenance_list"))
    return render_template("maintenance_form.html", record=record, vehicles=vehicles)


@app.post("/maintenance/<int:record_id>/delete")
@login_required
def maintenance_delete(record_id):
    record = MaintenanceRecord.query.get_or_404(record_id)
    db.session.delete(record)
    db.session.commit()
    flash("Maintenance record deleted.", "info")
    return redirect(url_for("maintenance_list"))


@app.route("/fuel")
@login_required
def fuel_list():
    logs = FuelLog.query.order_by(FuelLog.refuel_date.desc()).all()
    return render_template("fuel.html", logs=logs)


@app.route("/fuel/create", methods=["GET", "POST"])
@app.route("/fuel/<int:log_id>/edit", methods=["GET", "POST"])
@login_required
def fuel_form(log_id=None):
    log = FuelLog.query.get_or_404(log_id) if log_id else FuelLog(refuel_date=date.today())
    vehicles = Vehicle.query.order_by(Vehicle.plate_number).all()
    if request.method == "POST":
        log.vehicle_id = safe_int(request.form.get("vehicle_id"))
        log.refuel_date = parse_date(request.form.get("refuel_date")) or date.today()
        log.liters = safe_float(request.form.get("liters"), 0)
        log.price_per_liter = safe_float(request.form.get("price_per_liter"), 0)
        log.odometer = safe_int(request.form.get("odometer"), 0)
        log.station = request.form.get("station", "").strip()
        if not log_id:
            db.session.add(log)
        vehicle = Vehicle.query.get(log.vehicle_id)
        if vehicle:
            vehicle.odometer = log.odometer
        db.session.commit()
        flash("Fuel log saved successfully.", "success")
        return redirect(url_for("fuel_list"))
    return render_template("fuel_form.html", log=log, vehicles=vehicles)


@app.post("/fuel/<int:log_id>/delete")
@login_required
def fuel_delete(log_id):
    log = FuelLog.query.get_or_404(log_id)
    db.session.delete(log)
    db.session.commit()
    flash("Fuel log deleted.", "info")
    return redirect(url_for("fuel_list"))


@app.route("/reports")
@login_required
def reports():
    fuel_logs = FuelLog.query.all()
    maintenance_records = MaintenanceRecord.query.all()
    vehicles = Vehicle.query.order_by(Vehicle.plate_number).all()

    utilization = []
    fuel_costs = []
    maintenance_costs = []
    for vehicle in vehicles:
        distance = sum(t.distance_km for t in vehicle.trips)
        trip_count = len(vehicle.trips)
        utilization.append({"label": vehicle.plate_number, "distance": round(distance, 2), "trips": trip_count})
        fuel_costs.append({"label": vehicle.plate_number, "cost": round(sum(log.total_cost for log in vehicle.fuel_logs), 2)})
        maintenance_costs.append({"label": vehicle.plate_number, "cost": round(sum(item.cost for item in vehicle.maintenance_records), 2)})

    totals = {
        "fleet_distance": round(sum(item["distance"] for item in utilization), 2),
        "fuel_cost": round(sum(log.total_cost for log in fuel_logs), 2),
        "maintenance_cost": round(sum(item.cost for item in maintenance_records), 2),
    }

    return render_template(
        "reports.html",
        utilization=utilization,
        fuel_costs=fuel_costs,
        maintenance_costs=maintenance_costs,
        totals=totals,
    )


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
